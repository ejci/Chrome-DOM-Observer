/**
 *
 */
KONST = {};
KONST.settings = {};
KONST.settings.console = false;
KONST.settings.autostop = true;
KONST.settings.preserve = false;
KONST.settings.childChanges = false;

KONST.settings.version = '1';
